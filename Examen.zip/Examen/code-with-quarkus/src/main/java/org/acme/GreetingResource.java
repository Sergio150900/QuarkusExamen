package org.acme;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Path("/recurso")
public class GreetingResource {

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Map<String, Object> conseguirAAge(Map<String, String> payload) throws ParseException {
        Map<String, Object> map = new HashMap<>();
        String dateJson = payload.get("usuarioDate");
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date usuarioDate = formatter.parse(dateJson);
        Date dateActual = new Date();
        LocalDate localDate1 = usuarioDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localDate2 = dateActual.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        long age = ChronoUnit.YEARS.between(localDate1, localDate2);
        map.put("age", age);
        Calendar cal = Calendar.getInstance();
        cal.setTime(usuarioDate);
        int year = cal.get(Calendar.YEAR);
        if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0){
            map.put("bisiesto", true);
        }else{
            map.put("bisiesto", false);
        }
        return map;
    }

    @POST
    @Path("/comparacion")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Map<String, Object> comparacionAge(Map<String, String> payload) {
        Map<String, Object> respuesta = new HashMap<>();
        String mayorOMenor;
        if (payload.containsKey("age")) {
            String ageJson = payload.get("age");
            int age;
            try {
                age = Integer.parseInt(ageJson);
            }catch (Exception e){
                return (Map<String, Object>) respuesta.put("error", e.getLocalizedMessage().toString());
            }
            if (age > 26) {
                mayorOMenor = age + " , Andres es menor";
            } else if (age < 26) {
                mayorOMenor = age + " , Andres es mayor";
            } else {
                mayorOMenor = "misma edad";
            }
            respuesta.put("respuesta", mayorOMenor);
        } else {
            respuesta.put("error", "No se encontro la edad");
        }
        return respuesta;
    }



}
